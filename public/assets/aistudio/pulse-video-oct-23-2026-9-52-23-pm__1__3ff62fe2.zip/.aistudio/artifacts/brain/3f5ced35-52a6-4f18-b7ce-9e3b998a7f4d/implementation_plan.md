# Official Material 3 Expressive Theme & Me-Tab Component Upgrade

Replace the custom `MaterialExpressiveTheme` and `MotionScheme` in the application theme with Google's official Jetpack Compose Material 3 Expressive library APIs, and upgrade eligible hand-made controls in the **Me** tab and its sub-pages to official Material 3 Expressive components while leaving all other tabs, playback, MediaStore scanning, and navigation behavior untouched.

## User Review & Critical Decisions

> [!IMPORTANT]
> Both key implementation choices were confirmed during clarification and govern the scope of this change:

- **Confirmed Decision 1 (Theme + Me-Tab Official Components)**: Delete the custom `MaterialExpressiveTheme` and `MotionScheme` wrapper in `Theme.kt`, wire the official `androidx.compose.material3.MaterialExpressiveTheme` with `motionScheme = MotionScheme.expressive()` (annotated with `@OptIn(ExperimentalMaterial3ExpressiveApi::class)`), and swap hand-made imitations in the **Me** tab and its sub-pages (such as the Theme Mode segmented button group and switches) for official Material 3 / Material 3 Expressive components.
- **Confirmed Decision 2 (Dependency Pinning Strategy)**: Update the Compose BOM (`composeBom`) and explicitly pin `androidx.compose.material3:material3` to the latest 1.4+ / 1.5-alpha Expressive-capable release in the Gradle Version Catalog so all official Expressive APIs (`MaterialExpressiveTheme`, `MotionScheme.expressive()`, `ExperimentalMaterial3ExpressiveApi`, `ButtonGroup` / `ToggleButton`, `Switch`) resolve cleanly.

---

## 1. Overview & Core Concept

- **What It Does**: Transitions the **Videos** Android app from a locally defined `MaterialExpressiveTheme` / `MotionScheme` shim to the official `androidx.compose.material3` Expressive theme engine and physics-based motion tokens, while adopting official Material 3 Expressive controls inside the **Me** tab and its sub-pages.
- **Target Audience / Persona**: Single-device Android 16 user who wants authentic Material 3 Expressive physics, spatial/effects spring tokens (`MaterialTheme.motionScheme`), and official Material 3 Expressive widgets.
- **Key Value**: Eliminates custom boilerplate shims in favor of Google's first-party Material 3 Expressive implementation while preserving every existing color scheme (Dynamic Color, Indigo, Amber, Slate, Forest Green, Ocean, Custom HSV/Hex seed, and AMOLED Pure Black).

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **App Launch & Theme Initialization**: `PulseVideoTheme` computes the active `ColorScheme` (Android 12+ Dynamic Color, preset palette, or custom seed color with optional AMOLED black override) and passes it into `androidx.compose.material3.MaterialExpressiveTheme` with `motionScheme = MotionScheme.expressive()`.
  2. **Me Tab & Sub-Pages**:
     - Navigating between the **Me** home menu and its five sub-pages (**Video Playlist**, **Video History**, **Appearance**, **Video**, **Navigation**) uses the official `MaterialTheme.motionScheme.defaultSpatialSpec()` and `defaultEffectsSpec()` spring curves.
     - On the **Appearance** sub-page, the **Theme mode** selector (`System`, `Light`, `Dark`) uses official Material 3 Expressive connected toggle/segmented button components (`ButtonGroup` / `ToggleButton` or `SingleChoiceSegmentedButtonRow`), and toggle rows across **Appearance**, **Video**, and **Navigation** sub-pages use the official Material 3 `Switch` styled with the active expressive palette.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Authentic Google Material 3 Expressive (Material You Expressive) with emphasized `PlusJakartaSans` typography, expressive shapes (`ExpressiveShapes`), and spring-driven spatial motion.
  - *Color Palette & Mood*: Preserves the existing `LocalM3Palette` and `ColorScheme` mapping across `System`, `Light`, and `Dark` modes, Android 12+ `dynamicDarkColorScheme` / `dynamicLightColorScheme`, the 5 preset palettes (`Indigo`, `Amber`, `Slate`, `Forest Green`, `Ocean`), the custom HSV/Hex seed generator, and `AMOLED Black`.
  - *Typography & Hierarchy*: Retains `ExtraBold` top-level tab titles, `SemiBold` card and row titles, and `Normal` weight `onSurfaceVariant` subtitles.
- **Interactive Feedback & Motion**:
  - `MaterialTheme.motionScheme` provides official `fastSpatialSpec()`, `defaultSpatialSpec()`, `slowSpatialSpec()`, `fastEffectsSpec()`, and `defaultEffectsSpec()` animations throughout `MeTabScreen`.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Official `MaterialExpressiveTheme` & `MotionScheme.expressive()` Integration**
  - *Chosen Approach*: Remove the custom `MotionScheme` class, `LocalMotionScheme`, and custom `MaterialExpressiveTheme` function from the theme layer, and call `androidx.compose.material3.MaterialExpressiveTheme(colorScheme = baseScheme, motionScheme = MotionScheme.expressive(), shapes = ExpressiveShapes, typography = Typography, content = content)` with `@OptIn(ExperimentalMaterial3ExpressiveApi::class)`.
  - *Why*: Directly satisfies the requirement to use Google's real Material 3 Expressive theme and motion scheme rather than a custom wrapper, exposing `MaterialTheme.motionScheme` to all child composables.
  - *Alternatives Considered*: Keeping `LocalMotionScheme` alongside the official `MotionScheme` was rejected to avoid duplicate motion providers.
- **Decision 2: Scoped Component Replacement in the Me Tab Only**
  - *Chosen Approach*: Upgrade the hand-made controls inside the **Me** tab and its sub-pages (the 3-way Theme Mode selector in **Appearance** and the toggle switches in **Appearance**, **Video**, and **Navigation**) to official Material 3 Expressive components while keeping all other screens (`Videos`, `Folders`, `Audio`, `VideoPlayerModal`, bottom navigation pill) completely untouched.
  - *Why*: Strictly honors the constraint to only swap hand-made imitations in the Me tab and its sub-pages without redesigning or altering any other part of the application.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         Gradle Version Catalog                            │
│  • composeBom (Updated) + androidx.compose.material3 (1.4+ / Expressive)  │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                           PulseVideoTheme                                 │
│  • Computes baseScheme & basePalette (Dynamic / Preset / Custom / AMOLED) │
│  • Calls official androidx.compose.material3.MaterialExpressiveTheme(     │
│      colorScheme = baseScheme,                                            │
│      motionScheme = MotionScheme.expressive(),                            │
│      shapes = ExpressiveShapes,                                           │
│      typography = Typography                                              │
│    )                                                                      │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                      MeTabScreen & Sub-Pages                              │
│  • Uses official MaterialTheme.motionScheme spatial/effects specs         │
│  • AppearanceSubPage: Official Expressive ButtonGroup / ToggleButtons     │
│    for Theme Mode (System / Light / Dark)                                 │
│  • Appearance, Video & Navigation Sub-Pages: Official Material 3 Switch   │
│    with thumb check icon & Minimum-One-Tab disabled state support         │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - Zero changes to `VideoUiState`, `VideoPlayerViewModel`, `AppPreferencesRepository`, `MediaStoreScanner`, or `ExoPlayerController`.
- **Interactive Component & State Mapping**:
  - `PulseVideoTheme`: Annotated with `@OptIn(ExperimentalMaterial3ExpressiveApi::class)`, provides `LocalM3Palette` and delegates theme/motion rendering to `androidx.compose.material3.MaterialExpressiveTheme`.
  - `MeTabScreen`: Reads `MaterialTheme.motionScheme` (annotated with `@OptIn(ExperimentalMaterial3ExpressiveApi::class)`) for sub-page transitions and uses official Material 3 Expressive controls for the Theme Mode selector and setting switches while preserving all existing callbacks and test tags.
